The graph learning was done on a camera dataset which contains details of 1000+ cameras with 14 attributes each. The idea is to learn a graph to associate how each camera is related to each other.

1. Run the Data_preprocessing.ipynb first
2. Then run the learn_graph.ipynb to generate graph